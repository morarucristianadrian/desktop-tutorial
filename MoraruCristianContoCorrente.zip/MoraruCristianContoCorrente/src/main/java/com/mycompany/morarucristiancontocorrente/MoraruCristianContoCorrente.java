/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.morarucristiancontocorrente;

/**
 *
 * @author moraru.cristianadria
 */
public class MoraruCristianContoCorrente 
{
    /**
     * 
     * @param args 
     */
    
    public static void main(String[] args) 
    {
      ContoCorrente c1 = new ContoCorrente("Cristian","Moraru",50);
      
       c1.versamento(100);
       
        System.out.println(c1.ToString());
        System.out.println("il saldo dopo il versamento e' di " + c1.getSaldo());
         c1.prelievo(160);
        System.out.println("il saldo dopo il prelievo e' di " + c1.getSaldo());
    }
    
    
    
    
    
    
}
