/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.morarucristiancontocorrente;

/**
 *
 * @author moraru.cristianadria
 */
public class ContoCorrente 
{
public String nome,cognome;
public float saldo,capitaleIniziale;

public ContoCorrente(String nome,String cognome,float capitaleIniziale)
{
    this.capitaleIniziale=capitaleIniziale;
    this.nome=nome;
    this.cognome=cognome; 
    this.saldo = this.capitaleIniziale;
}

public String getNome()
{
    return nome;
}

public String getCognome()
{
    return cognome;
}

public float getCapitaleIniziale()
{
    return capitaleIniziale;
}

public float getSaldo()
{
    return saldo;
}

public void versamento(float i)
{ 
    saldo=saldo+i; 
}   

public void prelievo(float i)
{
    if(saldo >= i)
    {
     saldo = saldo - i;
    }
    else
    {
        System.out.println(" il prelievo non e' disponibile");
    }
    
}

public String ToString()
{
    return "il capitale iniziale e' di " + capitaleIniziale + " euro";
}







}




